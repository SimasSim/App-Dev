# Program Name: Coin Counter.py
# Course: IT3883/Section W02
# Student Name: Simas Simokaitis
# Assignment Number: Final Exam
# Due Date: 05/3/2025
# Purpose: A program that recives statements describing an amount of money in coins that converts theat to dollar amount
# List Specific resources used to complete the assignment

# Map singular coin names to their values in dollars
coin_values = {
    "penny": 0.01,
    "nickel": 0.05,
    "dime": 0.10,
    "quarter": 0.25
}

def parse_input(sentence):
    parts = sentence.lower().split(" and ")
    total = 0.0
    for part in parts:
        tokens = part.strip().split()
        quantity = int(tokens[0])
        denomination = tokens[1]

        # Normalize plural forms
        if denomination.endswith("ies"):
            denomination = "penny"
        elif denomination.endswith("s"):
            denomination = denomination[:-1]

        value = coin_values[denomination]
        total += quantity * value

    return f"{total:.2f}"

# Main function
if __name__ == "__main__":
    user_input = input("Enter coin amounts separated by and: ")
    dollar_amount = parse_input(user_input)
    print(f"{dollar_amount}")